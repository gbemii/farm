from django.contrib import admin
from adminstrator.models import *
# Register your models here.

admin.site.register( Admin_info)
# admin.site.register(Account)
# admin.site.register(Kyc_user_info)
admin.site.register(Farm)
# admin.site.register(Transactions)